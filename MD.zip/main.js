function _0x126a(_0x5a25, _0x5dbc45) {
  _0x5a25 = _0x5a25 - 0x1ec;
  const _0x3a932a = _0x3a93();
  let _0x126a0b = _0x3a932a[_0x5a25];
  return _0x126a0b;
}
function _0x3a93() {
  const _0x49276c = ["‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-", 'reloadHandler', '401185trAnvj', 'keys', 'webp', 'yellow', 'opts', "Your Pairing Code : ", 'creds', '-frames:v', 'data', 'localeCompare', '-hide_banner', 'READ', 'red', 'CONNECTING', 'argv', "Please install ffmpeg for sending videos (pkg install ffmpeg)", 'syntax-error', "-- Please wait, generating code... --", 'onDelete', ", isLatest: ", 'match', 'timestamp', 'participantsUpdate', 'all', 'join', 'tmpdir', 'connection.update', 'chalk', 'close', 'child', 'white', 'bye', 'spawn', 'Linux', 'blue', 'slice', "Stickers may not work without imagemagick if libwebp on ffmpeg doesnt isntalled (pkg install imagemagick)", './config', 'handler', 'logger', 'prefix', '--version', './sessions/creds.json', 'ubuntu', 'lodash', 'lowdb', 'readyState', 'write', 'loggedOut', 'map', 'authState', 'off', 'existsSync', 'forEach', 'RTXZYBOT', 'then', 'N/A', "Stickers may not animated without libwebp on ffmpeg (--enable-ibwebp while compiling ffmpeg)", 'stdout', "Quick Test Done", "syntax error while loading '", 'output', 'convert', 'info', 'get', 'replace', 'delete', "-- using WA v", '16nyWohe', 'length', 'DATABASE', 'Chrome', 'APIs', 'connect', 'NODE_TLS_REJECT_UNAUTHORIZED', 'exit', 'APIKeys', '-amin', 'isInit', 'parse', "Selamat datang @user di group @subject utamakan baca desk ya \n@desc", "Selamat tinggal @user 👋", '810528OwuanX', "Panggilan ditolak", '-filter_complex', "Panggilan diterima:", 'darwin', 'message.delete', 'creds.update', 'isArray', 'stdin', "requiring new plugin '", 'status', 'messages.upsert', 'readFileSync', 'black', 'uncaughtException', 'tmp', './lib/lowdb', 'fromEntries', '@adiwajshing/baileys', 'pino', 'ffmpeg', './lib/simple', 'chain', 'freeze', '316948ocyljF', '519968dehKSw', '12hYPLgj', '-delete', 'error', 'conn', 'readdirSync', 'cache', 'bind', './lib/mongoDB', 'store', 'credsUpdate', 'registered', 'test', 'done', 'log', 'requestPairingCode', 'support', '8608320AEOpby', "\\$&", 'question', 'connectionUpdate', '-loglevel', "@user sekarang bukan admin!", 'Windows', '1XaSPRY', '-type', 'bgWhite', 'resolve', 'blueBright', 'env', '829703pQCTcT', "ENTER A VALID NUMBER START WITH REGION CODE. Example : 62xxx:\n", "@user sekarang admin!", 'reload', 'loadDatabase', 'node-fetch', 'isBuffer', 'silent', 'PORT', 'node-cache', 'path', 'watch', 'filter', "-- WARNING: creds.json is broken, please delete it first --", '4752873cUdKxR', 'welcome', 'plugins', 'ffprobe', 'listMessage', 'catch', 'warn', 'magick', 'find'];
  _0x3a93 = function () {
    return _0x49276c;
  };
  return _0x3a93();
}
(function (_0x452a88, _0x2614fc) {
  const _0x5246aa = _0x452a88();
  while (true) {
    try {
      const _0xbbb01f = parseInt(_0x126a(0x1ed)) / 0x1 * (parseInt(_0x126a(0x277)) / 0x2) + parseInt(_0x126a(0x278)) / 0x3 * (-parseInt(_0x126a(0x276)) / 0x4) + -parseInt(_0x126a(0x20c)) / 0x5 + -parseInt(_0x126a(0x25e)) / 0x6 + -parseInt(_0x126a(0x1f3)) / 0x7 * (-parseInt(_0x126a(0x250)) / 0x8) + -parseInt(_0x126a(0x201)) / 0x9 + parseInt(_0x126a(0x288)) / 0xa;
      if (_0xbbb01f === _0x2614fc) {
        break;
      } else {
        _0x5246aa.push(_0x5246aa.shift());
      }
    } catch (_0x29ace5) {
      _0x5246aa.push(_0x5246aa.shift());
    }
  }
})(_0x3a93, 0x48a20);
process[_0x126a(0x1f2)][_0x126a(0x256)] = '1';
(async () => {
  require(_0x126a(0x231));
  const {
    useMultiFileAuthState: _0x5cfe7a,
    DisconnectReason: _0x3d634b,
    generateForwardMessageContent: _0x53724c,
    prepareWAMessageMedia: _0x106764,
    generateWAMessageFromContent: _0x495ab4,
    generateMessageID: _0x5bfc45,
    downloadContentFromMessage: _0x2c5833,
    makeCacheableSignalKeyStore: _0x5b8e37,
    makeInMemoryStore: _0x221f91,
    jidDecode: _0x170f4a,
    fetchLatestBaileysVersion: _0x511e27,
    proto: _0x5d8dc5,
    Browsers: _0x17793f
  } = await import(_0x126a(0x270));
  const _0x2cdcea = require(_0x126a(0x1fc));
  const _0x41b27f = require(_0x126a(0x271));
  const _0x58f199 = require('ws');
  const _0x948b0b = require(_0x126a(0x1fd));
  const _0x2ca79e = require('fs');
  const _0x317a59 = require('os');
  const _0x16812f = require('yargs/yargs');
  const _0xb63755 = require('child_process');
  const _0x5cceec = require(_0x126a(0x238));
  const _0xb841c4 = require(_0x126a(0x21c));
  const _0x2c540d = require(_0x126a(0x227));
  let _0x4a5504 = require(_0x126a(0x273));
  var _0x469652;
  try {
    _0x469652 = require(_0x126a(0x239));
  } catch (_0x37a6ff) {
    _0x469652 = require(_0x126a(0x26e));
  }
  const {
    Low: _0xbea280,
    JSONFile: _0x310f08
  } = _0x469652;
  const _0x3d707b = require(_0x126a(0x27f));
  const _0x46c5ce = require('readline');
  const _0x23bb87 = _0x46c5ce.createInterface({
    'input': process[_0x126a(0x266)],
    'output': process[_0x126a(0x246)]
  });
  const _0xb4cd16 = _0x16f235 => new Promise(_0x18ef1f => _0x23bb87[_0x126a(0x28a)](_0x16f235, _0x18ef1f));
  global.API = (_0x534a70, _0x1069fc = '/', _0x43f75c = {}, _0x172814) => (_0x534a70 in global[_0x126a(0x254)] ? global[_0x126a(0x254)][_0x534a70] : _0x534a70) + _0x1069fc + (_0x43f75c || _0x172814 ? '?' + new URLSearchParams(Object.entries({
    ..._0x43f75c,
    ...(_0x172814 ? {
      [_0x172814]: global[_0x126a(0x258)][_0x534a70 in global[_0x126a(0x254)] ? global[_0x126a(0x254)][_0x534a70] : _0x534a70]
    } : {})
  })) : '');
  global[_0x126a(0x221)] = {
    'start': new Date()
  };
  global[_0x126a(0x210)] = new Object(_0x16812f(process[_0x126a(0x21a)][_0x126a(0x22f)](0x2)).exitProcess(false)[_0x126a(0x25b)]());
  global[_0x126a(0x234)] = new RegExp('^[' + (opts[_0x126a(0x234)] || _0x126a(0x20a))[_0x126a(0x24d)](/[|\\{}()[\]^$+*?.\-\^]/g, _0x126a(0x289)) + ']');
  global.db = new _0xbea280(/https?:\/\//[_0x126a(0x283)](opts.db || '') ? new cloudDBAdapter(opts.db) : /mongodb/[_0x126a(0x283)](opts.db) ? new _0x3d707b(opts.db) : new _0x310f08((opts._[0x0] ? opts._[0x0] + '_' : '') + 'database.json'));
  global[_0x126a(0x252)] = global.db;
  global[_0x126a(0x1f7)] = async function _0x170f59() {
    if (global.db[_0x126a(0x217)]) {
      return new Promise(_0x44fd25 => setInterval(function () {
        if (!global.db.READ) {
          clearInterval(this);
          _0x44fd25(global.db[_0x126a(0x214)] == null ? global[_0x126a(0x1f7)]() : global.db[_0x126a(0x214)]);
        } else {
          null;
        }
      }, 1000));
    }
    if (global.db[_0x126a(0x214)] !== null) {
      return;
    }
    global.db[_0x126a(0x217)] = true;
    await global.db.read();
    global.db[_0x126a(0x217)] = false;
    global.db[_0x126a(0x214)] = {
      'users': {},
      'chats': {},
      'stats': {},
      'msgs': {},
      'sticker': {},
      ...(global.db[_0x126a(0x214)] || {})
    };
    global.db[_0x126a(0x274)] = _0x5cceec.chain(global.db[_0x126a(0x214)]);
  };
  loadDatabase();
  var _0x32bc6a = function (_0xc36608 = _0x126a(0x253)) {
    const _0x151484 = _0x317a59.platform();
    const _0x138927 = _0x151484 === 'win32' ? _0x126a(0x1ec) : _0x151484 === _0x126a(0x262) ? 'MacOS' : _0x126a(0x22d);
    const _0x4d6049 = _0x138927 === _0x126a(0x22d) ? _0x17793f[_0x126a(0x237)](_0xc36608)[0x2] : _0x126a(0x244);
    return [_0x138927, _0xc36608, _0x4d6049];
  };
  const _0xc2a98d = '' + (opts._[0x0] || 'sessions');
  global[_0x126a(0x25a)] = !_0x2ca79e[_0x126a(0x240)](_0xc2a98d);
  const {
    state: _0x3154ec,
    saveState: _0x283523,
    saveCreds: _0x219225
  } = await _0x5cfe7a(_0xc2a98d);
  const {
    version: _0xb1f3bb,
    isLatest: _0x1b3a1d
  } = await _0x511e27();
  console.log(_0x2c540d.magenta(_0x126a(0x24f) + _0xb1f3bb[_0x126a(0x224)]('.') + _0x126a(0x21f) + _0x1b3a1d + " --"));
  const _0x549ca3 = new _0x2cdcea();
  const _0x518836 = new _0x2cdcea({
    'stdTTL': 300,
    'useClones': false
  });
  const _0x12e594 = {
    'printQRInTerminal': false,
    'syncFullHistory': true,
    'markOnlineOnConnect': true,
    'connectTimeoutMs': 0xea60,
    'defaultQueryTimeoutMs': 0x0,
    'keepAliveIntervalMs': 0x2710,
    'generateHighQualityLinkPreview': true,
    'patchMessageBeforeSending': _0x12d7b3 => {
      const _0x1c10a5 = !!(_0x12d7b3.buttonsMessage || _0x12d7b3.templateMessage || _0x12d7b3[_0x126a(0x205)]);
      if (_0x1c10a5) {
        _0x12d7b3 = {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': {
                'deviceListMetadataVersion': 0x2,
                'deviceListMetadata': {}
              },
              ..._0x12d7b3
            }
          }
        };
      }
      return _0x12d7b3;
    },
    'auth': {
      'creds': _0x3154ec[_0x126a(0x212)],
      'keys': _0x5b8e37(_0x3154ec[_0x126a(0x20d)], _0x41b27f()[_0x126a(0x229)]({
        'level': 'silent',
        'stream': _0x126a(0x280)
      }))
    },
    'cachedGroupMetadata': async _0x53991d => _0x518836[_0x126a(0x24c)](_0x53991d),
    'msgRetryCounterCache': _0x549ca3,
    'browser': _0x32bc6a(),
    'logger': _0x41b27f({
      'level': _0x126a(0x1fa)
    }),
    'version': _0xb1f3bb
  };
  global.conn = _0x4a5504.makeWASocket(_0x12e594);
  if (!opts[_0x126a(0x283)]) {
    if (global.db) {
      setInterval(async () => {
        if (global.db[_0x126a(0x214)]) {
          await global.db[_0x126a(0x23b)]();
        }
        if (!opts[_0x126a(0x26d)] && (global[_0x126a(0x287)] || {})[_0x126a(0x209)]) {
          tmp = [_0x317a59[_0x126a(0x225)](), _0x126a(0x26d)];
          tmp[_0x126a(0x241)](_0x186b37 => _0xb63755.spawn(_0x126a(0x209), [_0x186b37, _0x126a(0x259), '3', _0x126a(0x1ee), 'f', _0x126a(0x279)]));
        }
      }, 30000);
    }
  }
  async function _0x2470b5(_0x553161) {
    const {
      connection: _0x547fd6,
      lastDisconnect: _0x495ebf
    } = _0x553161;
    global[_0x126a(0x221)][_0x126a(0x255)] = new Date();
    if (_0x495ebf && _0x495ebf[_0x126a(0x27a)] && _0x495ebf.error[_0x126a(0x249)] && _0x495ebf[_0x126a(0x27a)].output.statusCode !== _0x3d634b[_0x126a(0x23c)] && conn.ws[_0x126a(0x23a)] !== _0x58f199[_0x126a(0x219)]) {
      console.log(global[_0x126a(0x20b)](true));
    }
    if (global.db[_0x126a(0x214)] == null) {
      await loadDatabase();
    }
  }
  if (_0x2ca79e[_0x126a(0x240)](_0x126a(0x236)) && !conn[_0x126a(0x23e)][_0x126a(0x212)].registered) {
    console[_0x126a(0x285)](_0x2c540d[_0x126a(0x20f)](_0x126a(0x200)));
    process[_0x126a(0x257)](0x0);
  }
  if (!conn[_0x126a(0x23e)].creds[_0x126a(0x282)]) {
  let _0x100c6c = (global.numberowner || '').replace(/\D/g, '');

  if (!_0x100c6c || _0x100c6c.length < 0xa) {
    console[_0x126a(0x285)](
      _0x2c540d[_0x126a(0x218)]('global.numberowner invalid / empty')
    );
    process.exit(1);
  }

  console.log(
    _0x2c540d[_0x126a(0x1ef)](
      _0x2c540d[_0x126a(0x22e)](_0x126a(0x21d))
    )
  );

  setTimeout(async () => {
    try {
      let _0x2c8bd1 = _0x126a(0x242);
      let _0x39b448 = await conn[_0x126a(0x286)](_0x100c6c, _0x2c8bd1);
      _0x39b448 = _0x39b448?.[_0x126a(0x220)](/.{1,4}/g)?.[_0x126a(0x224)]('-') || _0x39b448;
      console[_0x126a(0x285)](
        _0x2c540d[_0x126a(0x26b)](_0x2c540d.bgGreen(_0x126a(0x211))),
        _0x2c540d[_0x126a(0x26b)](_0x2c540d[_0x126a(0x22a)](_0x39b448))
      );
    } catch (e) {
      console.error('Pairing failed:', e);
    }
  }, 0xbb8);
}
  process.on(_0x126a(0x26c), console[_0x126a(0x27a)]);
  const _0x59a8f9 = _0x570934 => {
    _0x570934 = require[_0x126a(0x1f0)](_0x570934);
    let _0x3c7977;
    let _0x1f2e34 = 0x0;
    do {
      if (_0x570934 in require[_0x126a(0x27d)]) {
        delete require[_0x126a(0x27d)][_0x570934];
      }
      _0x3c7977 = require(_0x570934);
      _0x1f2e34++;
    } while ((!_0x3c7977 || Array[_0x126a(0x265)](_0x3c7977) || _0x3c7977 instanceof String ? !(_0x3c7977 || []).length : typeof _0x3c7977 == 'object' && !Buffer[_0x126a(0x1f9)](_0x3c7977) ? !Object[_0x126a(0x20d)](_0x3c7977 || {})[_0x126a(0x251)] : true) && _0x1f2e34 <= 0xa);
    return _0x3c7977;
  };
  let _0x305e2d = true;
  global.reloadHandler = function (_0x446fef) {
    let _0x50fde0 = _0x59a8f9('./handler');
    if (_0x446fef) {
      try {
        global[_0x126a(0x27b)].ws.close();
      } catch {}
      global[_0x126a(0x27b)] = {
        ...global[_0x126a(0x27b)],
        ..._0x4a5504.makeWASocket(_0x12e594)
      };
    }
    if (!_0x305e2d) {
      conn.ev.off(_0x126a(0x269), conn[_0x126a(0x232)]);
      conn.ev[_0x126a(0x23f)]('group-participants.update', conn.participantsUpdate);
      conn.ev[_0x126a(0x23f)]('message.delete', conn[_0x126a(0x21e)]);
      conn.ev[_0x126a(0x23f)](_0x126a(0x226), conn[_0x126a(0x28b)]);
      conn.ev.off(_0x126a(0x264), conn[_0x126a(0x281)]);
    }
    conn[_0x126a(0x202)] = _0x126a(0x25c);
    conn[_0x126a(0x22b)] = _0x126a(0x25d);
    conn.promote = _0x126a(0x1f5);
    conn.demote = _0x126a(0x28d);
    conn[_0x126a(0x232)] = _0x50fde0[_0x126a(0x232)].bind(conn);
    conn.ev.on('call', async _0x3327b6 => {
      console.log(_0x126a(0x261), _0x3327b6);
      if (_0x3327b6[_0x126a(0x268)] === 'ringing') {
        await conn.rejectCall(_0x3327b6.id);
        console[_0x126a(0x285)](_0x126a(0x25f));
      }
    });
    conn[_0x126a(0x222)] = _0x50fde0[_0x126a(0x222)][_0x126a(0x27e)](conn);
    conn[_0x126a(0x21e)] = _0x50fde0[_0x126a(0x24e)][_0x126a(0x27e)](conn);
    conn.connectionUpdate = _0x2470b5[_0x126a(0x27e)](conn);
    conn[_0x126a(0x281)] = _0x219225[_0x126a(0x27e)](conn);
    conn.ev.on('messages.upsert', conn[_0x126a(0x232)]);
    conn.ev.on('group-participants.update', conn[_0x126a(0x222)]);
    conn.ev.on(_0x126a(0x263), conn[_0x126a(0x21e)]);
    conn.ev.on('connection.update', conn[_0x126a(0x28b)]);
    conn.ev.on(_0x126a(0x264), conn[_0x126a(0x281)]);
    _0x305e2d = false;
    return true;
  };
  let _0x214e2d = _0x948b0b[_0x126a(0x224)](__dirname, _0x126a(0x203));
  let _0x1a9a90 = _0x5af84a => /\.js$/[_0x126a(0x283)](_0x5af84a);
  global[_0x126a(0x203)] = {};
  for (let _0x27fe5c of _0x2ca79e[_0x126a(0x27c)](_0x214e2d)[_0x126a(0x1ff)](_0x1a9a90)) {
    try {
      global[_0x126a(0x203)][_0x27fe5c] = require(_0x948b0b[_0x126a(0x224)](_0x214e2d, _0x27fe5c));
    } catch (_0x54f3bc) {
      conn[_0x126a(0x233)][_0x126a(0x27a)](_0x54f3bc);
      delete global[_0x126a(0x203)][_0x27fe5c];
    }
  }
  console[_0x126a(0x285)](Object[_0x126a(0x20d)](global[_0x126a(0x203)]));
  global[_0x126a(0x1f6)] = (_0x2050db, _0x41c7f1) => {
    if (/\.js$/[_0x126a(0x283)](_0x41c7f1)) {
      let _0x5edafa = _0x948b0b.join(_0x214e2d, _0x41c7f1);
      if (_0x5edafa in require[_0x126a(0x27d)]) {
        delete require[_0x126a(0x27d)][_0x5edafa];
        if (_0x2ca79e[_0x126a(0x240)](_0x5edafa)) {
          conn[_0x126a(0x233)][_0x126a(0x24b)]("re - require plugin '" + _0x41c7f1 + "'");
        } else {
          conn[_0x126a(0x233)].warn("deleted plugin '" + _0x41c7f1 + "'");
          return delete global[_0x126a(0x203)][_0x41c7f1];
        }
      } else {
        conn[_0x126a(0x233)][_0x126a(0x24b)](_0x126a(0x267) + _0x41c7f1 + "'");
      }
      let _0x4cebfe = _0xb841c4(_0x2ca79e[_0x126a(0x26a)](_0x5edafa), _0x41c7f1);
      if (_0x4cebfe) {
        conn[_0x126a(0x233)].error(_0x126a(0x248) + _0x41c7f1 + "'\n" + _0x4cebfe);
      } else {
        try {
          global[_0x126a(0x203)][_0x41c7f1] = require(_0x5edafa);
        } catch (_0x57f326) {
          conn[_0x126a(0x233)][_0x126a(0x27a)](_0x57f326);
        } finally {
          global[_0x126a(0x203)] = Object[_0x126a(0x26f)](Object.entries(global.plugins).sort(([_0x3efd25], [_0x3aebad]) => _0x3efd25[_0x126a(0x215)](_0x3aebad)));
        }
      }
    }
  };
  Object[_0x126a(0x275)](global[_0x126a(0x1f6)]);
  _0x2ca79e[_0x126a(0x1fe)](_0x948b0b[_0x126a(0x224)](__dirname, 'plugins'), global[_0x126a(0x1f6)]);
  global[_0x126a(0x20b)]();
  async function _0x1e8a64() {
    let _0xc6655e = await Promise[_0x126a(0x223)]([_0xb63755[_0x126a(0x22c)](_0x126a(0x272)), _0xb63755[_0x126a(0x22c)](_0x126a(0x204)), _0xb63755.spawn(_0x126a(0x272), [_0x126a(0x216), _0x126a(0x28c), 'error', _0x126a(0x260), 'color', _0x126a(0x213), '1', '-f', _0x126a(0x20e), '-']), _0xb63755.spawn(_0x126a(0x24a)), _0xb63755[_0x126a(0x22c)](_0x126a(0x208)), _0xb63755.spawn('gm'), _0xb63755.spawn(_0x126a(0x209), [_0x126a(0x235)])][_0x126a(0x23d)](_0xecc590 => {
      return Promise.race([new Promise(_0x4ea945 => {
        _0xecc590.on('close', _0x403dac => {
          _0x4ea945(_0x403dac !== 0x7f);
        });
      }), new Promise(_0x553ced => {
        _0xecc590.on('error', _0x48ad9b => _0x553ced(false));
      })]);
    }));
    let [_0x7ce64e, _0x1623b7, _0x489cb1, _0x502eee, _0x6e7e00, _0x4e37eb, _0xb8bb18] = _0xc6655e;
    console[_0x126a(0x285)](_0xc6655e);
    let _0x573111 = global[_0x126a(0x287)] = {
      'ffmpeg': _0x7ce64e,
      'ffprobe': _0x1623b7,
      'ffmpegWebp': _0x489cb1,
      'convert': _0x502eee,
      'magick': _0x6e7e00,
      'gm': _0x4e37eb,
      'find': _0xb8bb18
    };
    Object[_0x126a(0x275)](global[_0x126a(0x287)]);
    if (!_0x573111[_0x126a(0x272)]) {
      conn[_0x126a(0x233)][_0x126a(0x207)](_0x126a(0x21b));
    }
    if (_0x573111.ffmpeg && !_0x573111.ffmpegWebp) {
      conn[_0x126a(0x233)][_0x126a(0x207)](_0x126a(0x245));
    }
    if (!_0x573111[_0x126a(0x24a)] && !_0x573111[_0x126a(0x208)] && !_0x573111.gm) {
      conn[_0x126a(0x233)].warn(_0x126a(0x230));
    }
  }
  _0x1e8a64()[_0x126a(0x243)](() => conn[_0x126a(0x233)][_0x126a(0x24b)](_0x126a(0x247)))[_0x126a(0x206)](_0x126a(0x284));
})();